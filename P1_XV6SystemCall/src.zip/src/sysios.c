#include "types.h"
#include "stat.h"
#include "user.h"
#include "iostat.h"


void sysios(int m, int n){
  void* dummy = 0;

  for(int i = 0 ; i < m ; i++){
    read(-1, dummy, 1); 
  }
  for(int j = 0 ; j < n ; j++){
    write(-1, dummy, 1); 
  }
  struct iostat *iostat = malloc(sizeof(struct iostat*));

  int retVal = getiocounts(iostat);

  printf(1, "%d %d %d\n", retVal,iostat->readcount, iostat->writecount ); 
  exit();

}

int main(int argc, char *argv[]){
  int m = atoi(argv[1]);
  int n = atoi(argv[2]);
  sysios(m, n);
  exit();
}


